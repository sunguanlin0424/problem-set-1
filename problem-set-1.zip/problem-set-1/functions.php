<?php
// register Nav Walker class_alias
require_once('class-wp-bootstrap-navwalker.php');

//Nav Menus
register_nav_menus(array(
 'primary' => __('Primary Menu')
 ));

add_theme_support('menus');

add_theme_support('post-thumbnails');

?>